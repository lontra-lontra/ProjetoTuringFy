package com.pacote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SiteLabooApplicationTests {

	@Test
	void contextLoads() {
	}

}
