import React from 'react';
import logo from './logo.svg';
import './App.css';
import PaginaInicial from './PaginaInicial';

function App() {
  return (
    <div className="App">
      <PaginaInicial></PaginaInicial>
    </div>
  );
}

export default App;
